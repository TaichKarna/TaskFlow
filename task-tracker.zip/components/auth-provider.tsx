"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"

interface User {
  id: string
  name: string
  email: string
  role: "admin" | "user"
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string, role?: "admin" | "user") => Promise<void>
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for stored user data
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string) => {
    setLoading(true)
    // Mock login - in real app, this would call your API
    const mockUser: User = {
      id: "1",
      name: email === "admin@example.com" ? "Admin User" : "Regular User",
      email,
      role: email === "admin@example.com" ? "admin" : "user",
    }

    localStorage.setItem("user", JSON.stringify(mockUser))
    setUser(mockUser)
    setLoading(false)
  }

  const register = async (name: string, email: string, password: string, role: "admin" | "user" = "user") => {
    setLoading(true)
    // Mock registration
    const mockUser: User = {
      id: Date.now().toString(),
      name,
      email,
      role,
    }

    localStorage.setItem("user", JSON.stringify(mockUser))
    setUser(mockUser)
    setLoading(false)
  }

  const logout = () => {
    localStorage.removeItem("user")
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, login, register, logout, loading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
